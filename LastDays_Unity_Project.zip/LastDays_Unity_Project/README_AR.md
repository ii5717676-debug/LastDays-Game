# Last Days – آخر الأيام
## مشروع Unity Starter قابل للتوسعة

هذا ملف مشروع تأسيسي فعلي للعبة بقاء ثلاثية الأبعاد. يحتوي على أنظمة C# منفصلة وقابلة للربط داخل Unity:
- حركة لاعب وكاميرا منظور ثالث.
- الصحة والجوع والعطش والطاقة.
- حقيبة موارد وجمع الموارد والتفاعل.
- نقاط ومَحفظة داخل اللعبة.
- وصفات صناعة.
- زراعة وحصاد.
- بناء عناصر من Prefabs.
- زومبي باستخدام NavMeshAgent.
- دورة ليل ونهار.
- حفظ وتحميل JSON.
- Object Pooling.
- واجهة HUD اختيارية وأزرار لمس.

**مهم:** هذا ليس إصداراً نهائياً تجارياً جاهزاً للنشر، ولا يحتوي على نماذج ثلاثية الأبعاد أو أصوات أو خريطة فنية جاهزة. هذه ملفات الأنظمة البرمجية الأساسية؛ يلزم إنشاء المشهد وربط المراجع وإضافة الأصول داخل Unity كما هو موضح أدناه. لا يمكن إنشاء عالم مفتوح غني مثل GTA بمجرد سكربتات فقط.

## الإصدار المستهدف
Unity 6 (6000.0) مع قالب 3D Core أو Universal 3D.
السكربتات تستخدم واجهة Input Manager القديمة لتسهيل التجربة على الكمبيوتر. في Player Settings اجعل Active Input Handling = Both أو Input Manager (Old).

## إنشاء المشهد التجريبي
1. أنشئ مشروع Unity 6 جديداً باسم `LastDays`.
2. انسخ مجلد `Assets` من هذا المشروع إلى مجلد مشروعك.
3. أنشئ Scene باسم `GameWorld`.
4. أنشئ أرضية: GameObject > 3D Object > Plane، واجعل Scale = (20,1,20).
5. أنشئ Player من Capsule عند (0,1,0)، وأضف CharacterController و `PlayerController` و `SurvivalStats` و `Inventory` و `PlayerInteractor`.
6. أضف Main Camera، ثم `ThirdPersonCamera`، واربط Target باللاعب.
7. أضف GameObject فارغاً باسم `GameSystems` وأضف `GameManager` و `EconomySystem` و `DayNightCycle` و `SaveSystem`.
8. أضف Directional Light واربطه في `DayNightCycle`.
9. أضف Canvas مع TextMeshPro Text لعناصر HUD، ثم أضف `HUDController` واربط حقول النصوص. عند أول استخدام لـ TextMeshPro قد يطلب Unity استيراد TMP Essentials.
10. أنشئ عناصر موارد (Cube أو Model) وأضف `ResourceNode`، واضبط نوع المورد والكمية. أضف Collider واجعله غير Trigger.
11. ضع `PlayerInteractor` على اللاعب. اضغط E قرب المورد لجمعه.
12. أنشئ Prefab لمحصول: Cube صغير أو نموذج نبات. أنشئ أرضية زراعة عليها Collider و `FarmingPlot`، واربط Crop Prefab.
13. أنشئ Prefab لبناء (مثل Cube)، ثم أنشئ GameObject باسم BuildSystem وأضف `BuildingSystem` واربط Prefab. اضغط B للبناء إذا كان لدى اللاعب المواد المطلوبة.
14. لإنشاء زومبي: Capsule مع NavMeshAgent و `ZombieAI` و Collider. أنشئ NavMesh Surface أو استخدم نظام AI Navigation وثبّت الحزمة `com.unity.ai.navigation`، ثم Bake للسطح. اربط اللاعب في Target. الزومبي يحتاج سطح NavMesh مخبوزاً ليتمكن من الحركة.
15. اضغط F5 للحفظ وF9 للتحميل. يمكن تغيير المفاتيح من `SaveSystem`.

## عناصر التحكم الافتراضية
- WASD: حركة.
- Shift: جري.
- Space: قفز.
- E: جمع/تفاعل.
- B: بناء.
- F5: حفظ.
- F9: تحميل.

## إعداد Android
- ثبّت Android Build Support من Unity Hub.
- File > Build Profiles > Android.
- استخدم `MobileInputBridge` لربط أزرار UI باللاعب: استدعِ `SetMove(Vector2)`, `SetRun(bool)` و `Jump()`.
- استخدم URP، قلّل كثافة الأشجار والظلال، واستعمل LOD Groups وOcclusion Culling وObject Pooling.
- لا تضع آلاف العناصر النشطة في المشهد؛ استخدم تقسيم الجزيرة إلى مناطق وتحميلها تدريجياً.

## ربط HUD
أضف TextMeshProUGUI إلى Canvas واربط:
- Health Text
- Hunger Text
- Thirst Text
- Stamina Text
- Points Text
- Money Text
- Inventory Text

## ملاحظات تقنية
- `ItemData` هو ScriptableObject لتعريف الموارد. يمكن إنشاء العناصر من Assets > Last Days > Item.
- `Inventory` يخزن الكميات حسب ItemData.
- `CraftingSystem` يستخدم وصفات قابلة للضبط من Inspector.
- `SaveSystem` يحفظ بيانات اللاعب والحقيبة والاقتصاد في `Application.persistentDataPath`.
- نظام البناء التجريبي يضع Prefab أمام اللاعب؛ أضف لاحقاً معاينة شفافة وتصادمات وتدوير.
- نظام الزومبي تجريبي؛ أضف Animator وملفات حركة وصوت عند توفير الأصول.
