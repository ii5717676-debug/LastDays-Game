using UnityEngine;

namespace LastDays
{
    public class FarmingPlot : MonoBehaviour
    {
        public ItemData seedItem;
        public ItemData harvestItem;
        public GameObject cropPrefab;
        public float growSeconds = 60f;
        public int harvestAmount = 3;

        private float growth;
        private GameObject cropInstance;
        private bool planted;

        private void Update()
        {
            if (!planted || growth >= growSeconds) return;
            growth += Time.deltaTime;
            if (cropInstance != null)
                cropInstance.transform.localScale = Vector3.one * Mathf.Lerp(0.35f, 1f, growth / growSeconds);
        }

        public void Interact(Inventory inventory)
        {
            if (inventory == null) return;
            if (!planted)
            {
                if (seedItem == null || !inventory.Remove(seedItem, 1)) return;
                planted = true;
                growth = 0;
                if (cropPrefab != null)
                {
                    cropInstance = Instantiate(cropPrefab, transform.position + Vector3.up * 0.15f, Quaternion.identity, transform);
                    cropInstance.transform.localScale = Vector3.one * 0.35f;
                }
            }
            else if (growth >= growSeconds)
            {
                if (inventory.Add(harvestItem, harvestAmount))
                {
                    planted = false;
                    growth = 0;
                    if (cropInstance != null) Destroy(cropInstance);
                }
            }
        }
    }
}
