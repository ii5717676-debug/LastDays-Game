using UnityEngine;
using System;
using System.Collections.Generic;

namespace LastDays
{
    [Serializable]
    public class InventoryEntry
    {
        public ItemData item;
        public int amount;
        public InventoryEntry(ItemData data, int count) { item = data; amount = count; }
    }

    public class Inventory : MonoBehaviour
    {
        public int capacity = 24;
        public List<InventoryEntry> entries = new List<InventoryEntry>();
        public event Action OnInventoryChanged;

        public int CountOf(ItemData item)
        {
            InventoryEntry entry = entries.Find(e => e.item == item);
            return entry == null ? 0 : entry.amount;
        }

        public bool Add(ItemData item, int amount)
        {
            if (item == null || amount <= 0) return false;
            InventoryEntry entry = entries.Find(e => e.item == item);
            if (entry != null) entry.amount += amount;
            else
            {
                if (entries.Count >= capacity) return false;
                entries.Add(new InventoryEntry(item, amount));
            }
            OnInventoryChanged?.Invoke();
            return true;
        }

        public bool Remove(ItemData item, int amount)
        {
            if (item == null || amount <= 0) return false;
            InventoryEntry entry = entries.Find(e => e.item == item);
            if (entry == null || entry.amount < amount) return false;
            entry.amount -= amount;
            if (entry.amount <= 0) entries.Remove(entry);
            OnInventoryChanged?.Invoke();
            return true;
        }

        public bool Has(ItemData item, int amount) => CountOf(item) >= amount;
        public void Clear() { entries.Clear(); OnInventoryChanged?.Invoke(); }
    }
}
