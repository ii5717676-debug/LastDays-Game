using UnityEngine;

namespace LastDays
{
    public enum ItemCategory { Resource, Food, Water, Tool, Weapon, Building, Seed, Misc }

    [CreateAssetMenu(fileName = "NewItem", menuName = "Last Days/Item")]
    public class ItemData : ScriptableObject
    {
        public string itemId = "item";
        public string displayName = "Item";
        public ItemCategory category;
        [Min(0)] public int sellValue = 1;
        [Min(0)] public float hungerRestore;
        [Min(0)] public float thirstRestore;
        public Sprite icon;
        [TextArea] public string description;
    }
}
