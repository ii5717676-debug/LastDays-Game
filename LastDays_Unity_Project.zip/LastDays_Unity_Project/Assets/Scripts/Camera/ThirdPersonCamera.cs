using UnityEngine;

namespace LastDays
{
    public class ThirdPersonCamera : MonoBehaviour
    {
        public Transform target;
        public Vector3 offset = new Vector3(0f, 2.6f, -5f);
        public float followSmooth = 10f;
        public float lookHeight = 1.4f;
        public float mouseSensitivity = 2f;
        public float minPitch = -25f;
        public float maxPitch = 65f;
        public float collisionRadius = 0.2f;

        private float yaw;
        private float pitch = 12f;

        private void Start()
        {
            if (target != null) yaw = target.eulerAngles.y;
            Cursor.lockState = CursorLockMode.Locked;
        }

        private void LateUpdate()
        {
            if (target == null) return;
            if (GameManager.Instance != null && GameManager.Instance.IsPaused) return;

            if (Cursor.lockState == CursorLockMode.Locked)
            {
                yaw += Input.GetAxis("Mouse X") * mouseSensitivity;
                pitch -= Input.GetAxis("Mouse Y") * mouseSensitivity;
            }
            pitch = Mathf.Clamp(pitch, minPitch, maxPitch);

            Quaternion rotation = Quaternion.Euler(pitch, yaw, 0f);
            Vector3 focus = target.position + Vector3.up * lookHeight;
            Vector3 desired = focus + rotation * offset;

            Vector3 ray = desired - focus;
            if (Physics.SphereCast(focus, collisionRadius, ray.normalized, out RaycastHit hit, ray.magnitude))
                desired = focus + ray.normalized * Mathf.Max(0.25f, hit.distance - 0.08f);

            transform.position = Vector3.Lerp(transform.position, desired, followSmooth * Time.deltaTime);
            transform.rotation = Quaternion.LookRotation(focus - transform.position);
        }
    }
}
