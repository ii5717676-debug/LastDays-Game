using UnityEngine;
using System;

namespace LastDays
{
    public class EconomySystem : MonoBehaviour
    {
        public int points;
        public int money;
        public int pointsPerMoney = 10;
        public event Action OnEconomyChanged;

        public void AddPoints(int amount)
        {
            points = Mathf.Max(0, points + amount);
            OnEconomyChanged?.Invoke();
        }

        public bool ConvertPointsToMoney(int pointsToConvert)
        {
            if (pointsToConvert <= 0 || pointsToConvert > points || pointsPerMoney <= 0) return false;
            points -= pointsToConvert;
            money += pointsToConvert / pointsPerMoney;
            OnEconomyChanged?.Invoke();
            return true;
        }

        public bool SpendMoney(int amount)
        {
            if (amount < 0 || money < amount) return false;
            money -= amount;
            OnEconomyChanged?.Invoke();
            return true;
        }

        public void AddMoney(int amount)
        {
            money = Mathf.Max(0, money + amount);
            OnEconomyChanged?.Invoke();
        }

        public void Restore(int savedPoints, int savedMoney)
        {
            points = Mathf.Max(0, savedPoints);
            money = Mathf.Max(0, savedMoney);
            OnEconomyChanged?.Invoke();
        }
    }
}
