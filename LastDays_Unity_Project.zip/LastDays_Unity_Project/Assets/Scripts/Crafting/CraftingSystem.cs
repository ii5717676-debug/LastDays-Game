using UnityEngine;
using System;
using System.Collections.Generic;

namespace LastDays
{
    [Serializable]
    public class RecipeIngredient
    {
        public ItemData item;
        [Min(1)] public int amount = 1;
    }

    [CreateAssetMenu(fileName = "NewRecipe", menuName = "Last Days/Crafting Recipe")]
    public class CraftingRecipe : ScriptableObject
    {
        public string recipeName;
        public List<RecipeIngredient> ingredients = new List<RecipeIngredient>();
        public ItemData result;
        [Min(1)] public int resultAmount = 1;
    }

    public class CraftingSystem : MonoBehaviour
    {
        public Inventory inventory;

        public bool CanCraft(CraftingRecipe recipe)
        {
            if (recipe == null || inventory == null || recipe.result == null) return false;
            foreach (RecipeIngredient ingredient in recipe.ingredients)
                if (ingredient.item == null || !inventory.Has(ingredient.item, ingredient.amount)) return false;
            return true;
        }

        public bool Craft(CraftingRecipe recipe)
        {
            if (!CanCraft(recipe)) return false;
            foreach (RecipeIngredient ingredient in recipe.ingredients)
                inventory.Remove(ingredient.item, ingredient.amount);
            return inventory.Add(recipe.result, recipe.resultAmount);
        }
    }
}
