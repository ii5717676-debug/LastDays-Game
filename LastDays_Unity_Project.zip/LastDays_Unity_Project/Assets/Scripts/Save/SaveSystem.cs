using UnityEngine;
using System;
using System.IO;
using System.Collections.Generic;

namespace LastDays
{
    [Serializable]
    public class SavedItem
    {
        public string itemId;
        public int amount;
    }

    [Serializable]
    public class SaveData
    {
        public float health, hunger, thirst, stamina;
        public int points, money;
        public float px, py, pz;
        public List<SavedItem> items = new List<SavedItem>();
    }

    public class SaveSystem : MonoBehaviour
    {
        public SurvivalStats stats;
        public Inventory inventory;
        public EconomySystem economy;
        public Transform player;
        public KeyCode saveKey = KeyCode.F5;
        public KeyCode loadKey = KeyCode.F9;
        public string fileName = "lastdays_save.json";

        private string SavePath => Path.Combine(Application.persistentDataPath, fileName);

        private void Update()
        {
            if (Input.GetKeyDown(saveKey)) Save();
            if (Input.GetKeyDown(loadKey)) Load();
        }

        public void Save()
        {
            if (stats == null || inventory == null || economy == null || player == null) return;
            SaveData data = new SaveData
            {
                health = stats.health, hunger = stats.hunger, thirst = stats.thirst, stamina = stats.stamina,
                points = economy.points, money = economy.money,
                px = player.position.x, py = player.position.y, pz = player.position.z
            };
            foreach (InventoryEntry entry in inventory.entries)
                if (entry.item != null)
                    data.items.Add(new SavedItem { itemId = entry.item.itemId, amount = entry.amount });

            File.WriteAllText(SavePath, JsonUtility.ToJson(data, true));
            Debug.Log("Last Days: saved to " + SavePath);
        }

        public void Load()
        {
            if (!File.Exists(SavePath)) { Debug.LogWarning("No Last Days save file found."); return; }
            SaveData data = JsonUtility.FromJson<SaveData>(File.ReadAllText(SavePath));
            if (data == null) return;

            if (stats != null) stats.Restore(data.health, data.hunger, data.thirst, data.stamina);
            if (economy != null) economy.Restore(data.points, data.money);
            if (player != null) player.position = new Vector3(data.px, data.py, data.pz);

            if (inventory != null)
            {
                inventory.Clear();
                ItemData[] allItems = Resources.LoadAll<ItemData>("");
                foreach (SavedItem saved in data.items)
                {
                    ItemData found = Array.Find(allItems, item => item.itemId == saved.itemId);
                    if (found != null) inventory.Add(found, saved.amount);
                }
            }
            Debug.Log("Last Days: save loaded.");
        }
    }
}
