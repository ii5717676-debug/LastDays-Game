using UnityEngine;

namespace LastDays
{
    // اربط هذه الدوال بأزرار UI عبر Button OnClick أو EventTrigger.
    public class MobileInputBridge : MonoBehaviour
    {
        public PlayerController player;

        public void SetMoveX(float value)
        {
            if (player == null) return;
            player.SetMobileMove(new Vector2(value, 0f));
        }

        public void SetMoveY(float value)
        {
            if (player == null) return;
            player.SetMobileMove(new Vector2(0f, value));
        }

        public void SetRun(bool value)
        {
            if (player != null) player.SetMobileRun(value);
        }

        public void Jump()
        {
            if (player != null) player.MobileJump();
        }

        public void StopMove()
        {
            if (player != null) player.SetMobileMove(Vector2.zero);
        }
    }
}
