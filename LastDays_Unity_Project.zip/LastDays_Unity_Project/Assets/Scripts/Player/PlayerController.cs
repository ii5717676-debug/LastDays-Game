using UnityEngine;

namespace LastDays
{
    [RequireComponent(typeof(CharacterController))]
    public class PlayerController : MonoBehaviour
    {
        [Header("Movement")]
        public float walkSpeed = 3.5f;
        public float runSpeed = 6f;
        public float jumpHeight = 1.4f;
        public float gravity = -22f;
        public float rotationSpeed = 12f;
        public Transform cameraTransform;

        private CharacterController controller;
        private Vector3 verticalVelocity;
        private Vector2 mobileMove;
        private bool mobileRun;
        private bool mobileJump;

        public float CurrentMoveAmount { get; private set; }

        private void Awake() => controller = GetComponent<CharacterController>();

        private void Update()
        {
            if (GameManager.Instance != null && GameManager.Instance.IsPaused) return;

            Vector2 input = mobileMove;
            if (input.sqrMagnitude < 0.001f)
                input = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));

            input = Vector2.ClampMagnitude(input, 1f);
            Transform cam = cameraTransform != null ? cameraTransform : transform;
            Vector3 forward = cam.forward; forward.y = 0f; forward.Normalize();
            Vector3 right = cam.right; right.y = 0f; right.Normalize();
            Vector3 direction = forward * input.y + right * input.x;

            bool running = mobileRun || Input.GetKey(KeyCode.LeftShift);
            float speed = running ? runSpeed : walkSpeed;
            controller.Move(direction * speed * Time.deltaTime);
            CurrentMoveAmount = direction.magnitude * (running ? 1f : 0.65f);

            if (direction.sqrMagnitude > 0.01f)
            {
                Quaternion target = Quaternion.LookRotation(direction);
                transform.rotation = Quaternion.Slerp(transform.rotation, target, rotationSpeed * Time.deltaTime);
            }

            if (controller.isGrounded && verticalVelocity.y < 0f) verticalVelocity.y = -2f;
            if ((Input.GetButtonDown("Jump") || mobileJump) && controller.isGrounded)
                verticalVelocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
            mobileJump = false;
            verticalVelocity.y += gravity * Time.deltaTime;
            controller.Move(verticalVelocity * Time.deltaTime);
        }

        public void SetMobileMove(Vector2 value) => mobileMove = Vector2.ClampMagnitude(value, 1f);
        public void SetMobileRun(bool value) => mobileRun = value;
        public void MobileJump() => mobileJump = true;
    }
}
