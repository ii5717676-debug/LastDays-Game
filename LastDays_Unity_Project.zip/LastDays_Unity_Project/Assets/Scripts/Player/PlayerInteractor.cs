using UnityEngine;

namespace LastDays
{
    public class PlayerInteractor : MonoBehaviour
    {
        public float interactDistance = 3f;
        public Camera playerCamera;
        public Inventory inventory;
        public KeyCode interactKey = KeyCode.E;

        private void Awake()
        {
            if (inventory == null) inventory = GetComponent<Inventory>();
            if (playerCamera == null) playerCamera = Camera.main;
        }

        private void Update()
        {
            if (Input.GetKeyDown(interactKey)) Interact();
        }

        public void Interact()
        {
            if (playerCamera == null || inventory == null) return;
            Ray ray = playerCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0));
            if (Physics.Raycast(ray, out RaycastHit hit, interactDistance))
            {
                ResourceNode node = hit.collider.GetComponentInParent<ResourceNode>();
                if (node != null) node.Gather(inventory);

                FarmingPlot plot = hit.collider.GetComponentInParent<FarmingPlot>();
                if (plot != null) plot.Interact(inventory);
            }
        }
    }
}
