using UnityEngine;
using UnityEngine.AI;

namespace LastDays
{
    [RequireComponent(typeof(NavMeshAgent))]
    public class ZombieAI : MonoBehaviour
    {
        public Transform target;
        public float detectionRange = 15f;
        public float attackRange = 1.8f;
        public float attackDamage = 8f;
        public float attackCooldown = 1.5f;
        public float wanderRadius = 8f;
        public float wanderInterval = 5f;

        private NavMeshAgent agent;
        private float nextAttack;
        private float nextWander;
        private SurvivalStats targetStats;

        private void Awake() => agent = GetComponent<NavMeshAgent>();

        private void Start()
        {
            if (target != null) targetStats = target.GetComponent<SurvivalStats>();
        }

        private void Update()
        {
            if (target == null || !agent.isOnNavMesh) return;
            float distance = Vector3.Distance(transform.position, target.position);

            if (distance <= detectionRange)
            {
                agent.isStopped = false;
                agent.SetDestination(target.position);
                if (distance <= attackRange && Time.time >= nextAttack)
                {
                    nextAttack = Time.time + attackCooldown;
                    if (targetStats != null) targetStats.TakeDamage(attackDamage);
                }
            }
            else if (Time.time >= nextWander)
            {
                nextWander = Time.time + wanderInterval;
                Vector3 random = Random.insideUnitSphere * wanderRadius + transform.position;
                if (NavMesh.SamplePosition(random, out NavMeshHit hit, wanderRadius, NavMesh.AllAreas))
                {
                    agent.isStopped = false;
                    agent.SetDestination(hit.position);
                }
            }
        }
    }
}
