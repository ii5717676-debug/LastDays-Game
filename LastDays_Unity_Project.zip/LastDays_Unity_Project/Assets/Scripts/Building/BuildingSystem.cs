using UnityEngine;

namespace LastDays
{
    public class BuildingSystem : MonoBehaviour
    {
        public Inventory inventory;
        public ItemData requiredItem;
        public int requiredAmount = 5;
        public GameObject buildingPrefab;
        public Transform player;
        public float placeDistance = 3f;
        public KeyCode buildKey = KeyCode.B;

        private void Update()
        {
            if (Input.GetKeyDown(buildKey)) TryBuild();
        }

        public bool TryBuild()
        {
            if (inventory == null || player == null || buildingPrefab == null) return false;
            if (requiredItem != null && !inventory.Has(requiredItem, requiredAmount)) return false;
            Vector3 position = player.position + player.forward * placeDistance;
            position.y = Mathf.Max(0, position.y);
            if (requiredItem != null && !inventory.Remove(requiredItem, requiredAmount)) return false;
            Instantiate(buildingPrefab, position, Quaternion.identity);
            return true;
        }
    }
}
