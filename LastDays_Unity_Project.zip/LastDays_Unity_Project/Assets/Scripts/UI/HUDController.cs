using UnityEngine;
using TMPro;

namespace LastDays
{
    public class HUDController : MonoBehaviour
    {
        public SurvivalStats stats;
        public EconomySystem economy;
        public Inventory inventory;
        public TMP_Text healthText, hungerText, thirstText, staminaText, pointsText, moneyText, inventoryText;

        private void Update()
        {
            if (stats != null)
            {
                if (healthText != null) healthText.text = $"Health: {stats.health:0}";
                if (hungerText != null) hungerText.text = $"Hunger: {stats.hunger:0}";
                if (thirstText != null) thirstText.text = $"Thirst: {stats.thirst:0}";
                if (staminaText != null) staminaText.text = $"Stamina: {stats.stamina:0}";
            }
            if (economy != null)
            {
                if (pointsText != null) pointsText.text = $"Points: {economy.points}";
                if (moneyText != null) moneyText.text = $"Money: ${economy.money}";
            }
            if (inventory != null && inventoryText != null)
            {
                string display = "Inventory";
                foreach (InventoryEntry entry in inventory.entries)
                    if (entry.item != null) display += $"\n{entry.item.displayName}: {entry.amount}";
                inventoryText.text = display;
            }
        }
    }
}
