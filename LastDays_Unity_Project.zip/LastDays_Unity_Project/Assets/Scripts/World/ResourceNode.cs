using UnityEngine;

namespace LastDays
{
    public class ResourceNode : MonoBehaviour
    {
        public ItemData resource;
        public int amountAvailable = 5;
        public int amountPerGather = 1;
        public float respawnSeconds = 0f;

        private int startingAmount;
        private Renderer[] renderers;
        private Collider[] colliders;
        private float respawnTimer;

        private void Awake()
        {
            startingAmount = amountAvailable;
            renderers = GetComponentsInChildren<Renderer>();
            colliders = GetComponentsInChildren<Collider>();
        }

        private void Update()
        {
            if (amountAvailable <= 0 && respawnSeconds > 0)
            {
                respawnTimer -= Time.deltaTime;
                if (respawnTimer <= 0) RestoreNode();
            }
        }

        public bool Gather(Inventory inventory)
        {
            if (inventory == null || resource == null || amountAvailable <= 0) return false;
            int amount = Mathf.Min(amountPerGather, amountAvailable);
            if (!inventory.Add(resource, amount)) return false;
            amountAvailable -= amount;
            if (amountAvailable <= 0)
            {
                foreach (Renderer r in renderers) r.enabled = false;
                foreach (Collider c in colliders) c.enabled = false;
                if (respawnSeconds > 0) respawnTimer = respawnSeconds;
            }
            return true;
        }

        private void RestoreNode()
        {
            amountAvailable = startingAmount;
            foreach (Renderer r in renderers) r.enabled = true;
            foreach (Collider c in colliders) c.enabled = true;
        }
    }
}
