using UnityEngine;

namespace LastDays
{
    public class DayNightCycle : MonoBehaviour
    {
        public Light sun;
        [Min(1)] public float fullDayLengthMinutes = 20f;
        [Range(0, 1)] public float timeOfDay = 0.3f;
        public Gradient ambientColor;
        public AnimationCurve sunIntensity = AnimationCurve.EaseInOut(0, 0, 0.25f, 1);

        private void Update()
        {
            timeOfDay += Time.deltaTime / (fullDayLengthMinutes * 60f);
            if (timeOfDay >= 1f) timeOfDay -= 1f;

            float sunAngle = timeOfDay * 360f - 90f;
            if (sun != null)
            {
                sun.transform.rotation = Quaternion.Euler(sunAngle, 170f, 0f);
                float daylight = Mathf.Clamp01(Vector3.Dot(sun.transform.forward, Vector3.down));
                sun.intensity = sunIntensity.Evaluate(daylight);
            }

            if (ambientColor != null)
                RenderSettings.ambientLight = ambientColor.Evaluate(timeOfDay);
        }
    }
}
