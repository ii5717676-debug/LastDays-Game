إنشاء عناصر اللعبة:
1. انقر بزر الفأرة الأيمن داخل Assets وأنشئ مجلد Resources/Items.
2. Create > Last Days > Item.
3. أنشئ عناصر مثل Wood, Stone, Fish, Seed, Crop, WaterBottle.
4. اجعل itemId فريداً لكل عنصر.
5. ضع ملفات ItemData في مجلد Resources لكي يستطيع SaveSystem العثور عليها.
6. اربط ItemData في ResourceNode وFarmingPlot والوصفات.
