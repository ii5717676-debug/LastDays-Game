using UnityEngine;
using System;

namespace LastDays
{
    public class SurvivalStats : MonoBehaviour
    {
        [Range(0, 100)] public float health = 100f;
        [Range(0, 100)] public float hunger = 100f;
        [Range(0, 100)] public float thirst = 100f;
        [Range(0, 100)] public float stamina = 100f;
        public float hungerLossPerMinute = 1.2f;
        public float thirstLossPerMinute = 1.8f;
        public float staminaRecoveryPerSecond = 12f;
        public float starvationDamagePerSecond = 2f;
        public float dehydrationDamagePerSecond = 3f;

        public event Action OnStatsChanged;
        public bool IsDead => health <= 0f;

        private void Update()
        {
            float dt = Time.deltaTime;
            hunger = Mathf.Max(0, hunger - hungerLossPerMinute * dt / 60f);
            thirst = Mathf.Max(0, thirst - thirstLossPerMinute * dt / 60f);
            stamina = Mathf.Min(100, stamina + staminaRecoveryPerSecond * dt);

            if (hunger <= 0) TakeDamage(starvationDamagePerSecond * dt);
            if (thirst <= 0) TakeDamage(dehydrationDamagePerSecond * dt);
            OnStatsChanged?.Invoke();
        }

        public void TakeDamage(float amount) { health = Mathf.Clamp(health - Mathf.Max(0, amount), 0, 100); OnStatsChanged?.Invoke(); }
        public void Heal(float amount) { health = Mathf.Clamp(health + Mathf.Max(0, amount), 0, 100); OnStatsChanged?.Invoke(); }
        public void Eat(float amount) { hunger = Mathf.Clamp(hunger + Mathf.Max(0, amount), 0, 100); OnStatsChanged?.Invoke(); }
        public void Drink(float amount) { thirst = Mathf.Clamp(thirst + Mathf.Max(0, amount), 0, 100); OnStatsChanged?.Invoke(); }
        public bool UseStamina(float amount)
        {
            if (stamina < amount) return false;
            stamina -= amount; OnStatsChanged?.Invoke(); return true;
        }

        public void Restore(float h, float hu, float t, float s)
        {
            health = Mathf.Clamp(h, 0, 100); hunger = Mathf.Clamp(hu, 0, 100);
            thirst = Mathf.Clamp(t, 0, 100); stamina = Mathf.Clamp(s, 0, 100);
            OnStatsChanged?.Invoke();
        }
    }
}
