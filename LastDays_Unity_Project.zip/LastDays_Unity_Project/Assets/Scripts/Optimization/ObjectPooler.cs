using UnityEngine;
using System.Collections.Generic;

namespace LastDays
{
    public class ObjectPooler : MonoBehaviour
    {
        public GameObject prefab;
        [Min(1)] public int initialSize = 10;
        public bool expandable = true;

        private readonly Queue<GameObject> pool = new Queue<GameObject>();

        private void Awake()
        {
            if (prefab == null) return;
            for (int i = 0; i < initialSize; i++) CreateOne();
        }

        private GameObject CreateOne()
        {
            GameObject obj = Instantiate(prefab, transform);
            obj.SetActive(false);
            pool.Enqueue(obj);
            return obj;
        }

        public GameObject Get(Vector3 position, Quaternion rotation)
        {
            if (pool.Count == 0)
            {
                if (!expandable) return null;
                CreateOne();
            }
            GameObject obj = pool.Dequeue();
            obj.transform.SetPositionAndRotation(position, rotation);
            obj.SetActive(true);
            PooledObject marker = obj.GetComponent<PooledObject>();
            if (marker == null) marker = obj.AddComponent<PooledObject>();
            marker.SetOwner(this);
            return obj;
        }

        public void Return(GameObject obj)
        {
            if (obj == null) return;
            obj.SetActive(false);
            obj.transform.SetParent(transform);
            pool.Enqueue(obj);
        }
    }

    public class PooledObject : MonoBehaviour
    {
        private ObjectPooler owner;
        public void SetOwner(ObjectPooler value) => owner = value;
        public void Release()
        {
            if (owner != null) owner.Return(gameObject);
            else gameObject.SetActive(false);
        }
    }
}
